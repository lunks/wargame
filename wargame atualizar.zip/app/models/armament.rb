class Armament < Unit
end
