class Unit < GenericUnit
end
require 'fighter'
require 'light_transport'
require 'capital_ship'
require 'armament'
require 'trooper'
require 'warrior'

