class Facility < GenericUnit
 
  def capacity
    self.price / 3
  end

end

