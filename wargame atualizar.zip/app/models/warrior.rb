class Warrior < Unit

end
