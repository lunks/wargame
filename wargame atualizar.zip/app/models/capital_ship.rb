class CapitalShip < Unit

end

