class LightTransport < Unit
end
