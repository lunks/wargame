class Trooper < Unit
end

