class Fighter < Unit

end

