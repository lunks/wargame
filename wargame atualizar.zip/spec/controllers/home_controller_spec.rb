require 'spec_helper'

describe HomeController do

end
